const express = require('express');
const axios = require('axios');
const cheerio = require('cheerio');
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.static('public'));

app.get('/proxy', async (req, res) => {
  const targetUrl = req.query.url;
  if (!targetUrl) return res.status(400).send('URLが指定されていません');

  try {
    const response = await axios.get(targetUrl);
    const contentType = response.headers['content-type'];

    if (!contentType.includes('text/html')) {
      return res.send(`<pre>${response.data}</pre>`);
    }

    const $ = cheerio.load(response.data);

    $('head').prepend('<base href="' + targetUrl + '">');

    $('script').remove();
    $('link').each((_, el) => {
      const href = $(el).attr('href');
      if (href && href.startsWith('/')) {
        $(el).attr('href', targetUrl + href);
      }
    });

    $('img').each((_, el) => {
      const src = $(el).attr('src');
      if (src && src.startsWith('/')) {
        $(el).attr('src', targetUrl + src);
      }
    });

    $('a').each((_, el) => {
      const href = $(el).attr('href');
      if (href && !href.startsWith('http')) {
        $(el).attr('href', '/proxy?url=' + encodeURIComponent(new URL(href, targetUrl).href));
      } else if (href) {
        $(el).attr('href', '/proxy?url=' + encodeURIComponent(href));
      }
    });

    res.send($.html());
  } catch (err) {
    res.status(500).send('取得エラー: ' + err.message);
  }
});

app.listen(PORT, () => {
  console.log(`Sennin Proxy running on http://localhost:${PORT}`);
});